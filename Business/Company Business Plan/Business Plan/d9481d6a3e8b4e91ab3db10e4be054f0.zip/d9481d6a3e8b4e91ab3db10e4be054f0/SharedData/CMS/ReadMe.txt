ReadMe file for Intuit Content Management System(CMS)


This file contains a detailed description of the user information which is stored in One Intuit Content Management System.

The file uploaded under CMS folder contains details of the user generated content and stored in CMS.It may be empty, if no data is stored/available.

