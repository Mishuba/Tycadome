---------------------------------------------------------------------
 FILE NAME                         CONTENTS
---------------------------------------------------------------------
 customer_account_details.json     Customer account details
 customer_profile_details.json     Customer profile details
 customer_account_activities.json  Customer account activity
 customer_entitlements.json        Customer entitlement info
 customer_consents.json            Customer consent details
 data_sharing_permissions.json     Data Sharing permissions
---------------------------------------------------------------------

Note: When there is no data available for the given category,
the corresponding file will be empty.
