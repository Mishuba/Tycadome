The following file SharedCustomerData_B2C_CustomerCare_XXXXX.json contains information gathered during interactions you have had with Intuit.  These interactions include, but are not limited to: purchases; product registrations and activations; support calls, interactions and communications; account service calls, interactions and communications; management of your subscriptions; billing, payment and collections related activity; and marketing communications.  This data is not unique to any specific product you may own or use as you may be associated to many Intuit products or no Intuit products.

This specific file contains the following data subjects:  

Sales & Marketing Contact / Lead - An entity that has explicitly expressed a level of in Interest in Intuit and/or its product offerings and has provided some identifying information (e.g. email).  The Sales and Marketing Contact is the person (with or within the context of an organization) and the Lead is the person associated to an interested product group/product line.  Potential information captured: Company Name, Address, E-mail address, Contact Name, Related Ecosystem ID, Potentially a linkage to a Visitor Tracking ID, Activity participated in,Online behavior exhibited, Preference (opt-out, opt-down/opt-in)	

Sales & Marketing Communication - A record of a communication with a person that has been designated to have potential interest.  The communication could be come in many forms (e.g. email, phone dialog, chat, web dialog etc..).  Potential information captured: Sales and Marketing Contact/Lead ID, Marketing /Sales Communication History (structured web dialog, outbound sales contact notes, e-mail, text, etcÖ)	

Call Center Appointment  - A record associated to person calling into Intuit whereby an deferred contact with an agent is requested either when agent is available or at a scheduled time.  Potential information captured: Customer Name, Telephone Number, Email Address	

Intuit Enterprise Customer Account - An entity within the Intuit ecosystems that has chosen to do business with Intuit (i.e. a purchased or acquired an Intuit sold offering) Related to Ecosystem ID. Potential information captured: Customer Name, Address, Contact, e-mail address.

Entitled Product - These are the Intuit sold products that the customer is entitled to and the terms of use that are associated to these products.  In some systems these are called assets.These describe the contract that Intuit has agreed to provide to the customer in terms of products, features with any entitled limits.  Potential information captured:  Related Subscription (Optional), Related Product, Entitlement Attributes, Entitlement State

Support Case - A record of a call-in support request from an Intuit customer about a specific offering.  Used for tracking the customer problem to resolution.  Potential information captured:  Case Identifier, Contact, Related Product (Asset), Type (Chat, Call), Survey Results

Support Correspondence - Support related e-mail to customer customer related to a specific case. Potential information captured:  Case Identifier, Product, Context specific verbiage	