The following file SharedCustomerData_CustomerCare_CDB_XXXXX.json contains information gathered during interactions you have had with Intuit.  These interactions include, but are not limited to: purchases; product registrations and activations; support calls, interactions and communications; account service calls, interactions and communications; management of your subscriptions; billing, payment and collections related activity; and marketing communications.  This data is not unique to any specific product you may own or use as you may be associated to many Intuit products or no Intuit products.

This specific file contains the following data subjects:

Organization - A business that has purchased or acquired some Intuit sold offering. Potential information captured: Legal Name of the Business, Address, Phone Numbers, Emails, Contacts/Persons associated to the Business, Government Issued Identifier, Country of Operation, etc.

Person/User - An individual that has directly or indirectly chosen to do business with Intuit (i.e. a purchased or acquired an Intuit sold offering). He/She/They may be a direct customer of Intuit or may be associated with an organization that has an Intuit sold offering. Potential information captured: Name, phone Numbers, Emails, Government Issued Identifier, Addressed, Usernames, etc.

Intuit Enterprise Customer Account - An entity within the Intuit ecosystems that has chosen to do business with Intuit (i.e. a purchased or acquired an Intuit sold offering). Potential information captured: Customer Name, Address, Contact, e-mail address.

Entitled Product - These are the Intuit sold products that the customer is entitled to and the terms of use that are associated to these products.  In some systems these are called assets. These describe the contract that Intuit has agreed to provide to the customer in terms of products, features with any entitled limits.  Potential information captured:  Related Subscription (Optional), Related Product, Entitlement Attributes, Entitlement State
