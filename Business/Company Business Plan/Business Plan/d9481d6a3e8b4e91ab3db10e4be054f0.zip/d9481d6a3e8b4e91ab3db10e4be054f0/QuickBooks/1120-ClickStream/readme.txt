ReadMe file for Clickstream Data

You've successfully downloaded a copy of the clickstream data you requested.

This file contains the downloaded data you requested.
Activity.zip which consists of:- Clickstream0.json - Click stream data
