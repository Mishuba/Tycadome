"The following file MarketingInformation.json contains information gathered during interactions you have had with Intuit.

Mobile App Marketing Data - Identity and Marketing campaign data results of marketing communications of our native apps. Potential information captured: Name, Email, campaigns received, canvas's (dynamic campaigns) received."