ReadMe file for Trips,

This file contains a detailed description of your downloaded trips data, including dataset name, an explanation of the info contained in each dataset, and file format.

If the list of files are blank, it may mean you haven’t shared enough data with us or our products for it to be stored. If this doesn’t seem right, please double-check you entered your info correctly and request your data again.


Trips

This file contains descriptions of the downloaded data you requested.


   - File TRIP.csv - List of trip entries
   - File VEHICLE.csv - List of vehicle entries
   - File RULE.csv - List of rule entries
   - File PLACE.csv - List of place entries

