ReadMe file for Analytics

This file contains a detailed description of your downloaded Analytics data, including dataset name, an explanation of the info contained in each dataset, and file format.

If this file is blank, it may mean you haven’t shared enough data with us or our products for it to be stored. If this doesn’t seem right, please double-check you entered your info correctly and request your data again.


Analytics

This file contains descriptions of the downloaded data you requested.
Activity.zip which consists of:
- Activity1.csv - Analytics data
- Activity2.csv - Analytics data
