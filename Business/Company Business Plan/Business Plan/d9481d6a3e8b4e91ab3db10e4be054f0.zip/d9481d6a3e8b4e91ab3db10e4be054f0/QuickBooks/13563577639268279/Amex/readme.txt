ReadMe file for Amex Service
Filename: readme.txt

This file contains Amex transactions for the connected Amex accounts in QuickBooks.

If this file is blank, it may mean you haven’t shared enough data with us or our products for it to be stored. If this doesn’t seem right, please double-check you entered your info correctly and request your data again.


QuickBooks Amex data:
The CSV file may contain transactions which you have done through the Amex accounts connected to QuickBooks.
Filename: <company_Id>_<YYYY-MM-DD>T<HH_MM_SS_sss>Z_purchases.csv
Filename: <company_Id>_<YYYY-MM-DD>T<HH_MM_SS_sss>Z_transfers.csv

This file contains descriptions of the downloaded data you requested. 
The CSV file may contain transactions which you have done through the above mentioned channel connected to QuickBooks.

