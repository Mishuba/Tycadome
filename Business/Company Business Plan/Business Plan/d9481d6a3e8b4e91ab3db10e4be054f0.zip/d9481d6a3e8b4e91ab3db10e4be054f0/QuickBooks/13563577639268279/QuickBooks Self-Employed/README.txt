ReadMe file for QuickBooks Self-Employed,

This file contains a detailed description of your downloaded QuickBooks Self-Employed data, including dataset name, an explanation of the info contained in each dataset, and file format.

If this file is blank, it may mean you haven?t shared enough data with us or our products for it to be stored. If this doesn?t seem right, please double-check you entered your info correctly and request your data again.


QuickBooks Self-Employed

This file contains descriptions of the downloaded data you requested.


   - File UtmInfo.json - 
   - File FiAccount.json - This contains information about bank accounts you have connected.
   - File FiConnection.json - 
   - File UserTaxInfo.json - This contains information related to filing your taxes.
   - File UserGuidance.json - This contains tracking information about what 'guidance' hints have been seen 
   - File UserPreference.json - 
   - File Rule.json - 
   - File Transaction.json - This contains transaction data that was imported via a bank connection or manually entered into QuickBooks Self-Employed.

