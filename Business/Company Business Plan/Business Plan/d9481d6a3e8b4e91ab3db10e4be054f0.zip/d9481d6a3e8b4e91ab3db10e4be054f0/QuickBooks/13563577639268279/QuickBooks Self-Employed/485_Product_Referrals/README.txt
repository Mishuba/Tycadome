
    README file for QuickBooks Self-Employed product referral information.

    This folder contains a single file, ReferralInformation.json
    with information about referrals you may have made for QuickBooks Self-Employed.

    This includes the following data points:
    - Offer count. This represents how many unique offers you referred people with.
    - Share count. This represents how many times you shared referral information about QuickBooks Self-Employed.
    - Conversion count. This represents how many times the referral information you shared resulted in a new user to QuickBooks Self-Employed.
    - Purchase count. This represents how many times the referral information you shared resulted in a new subscriber to QuickBooks Self-Employed.
    - PURLs. The data in this field represents a collection of unique codes that were used to share referral information in URL links.
    - User agents. This represents the "User Agent" of web browsers you used to share referral information.
    - IP addresses.  This represents the IP addresses you used to share referral information.
    - Facebook profiles. This represents the facebook profiles you used to share referral information.
    