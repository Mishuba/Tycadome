ReadMe File

This file contains a detailed description of your downloaded data, including dataset name, an explanation of the info contained in each dataset, and file format.
The files listed may not have data related to you and therefore will not be present for review. If this doesn’t seem right, please double-check you entered your info correctly and request your data again.

This file contains descriptions of the downloaded data you requested.

preparerinfo.txt - contains tax preparer profile information
analytics_group_1.txt - contains first group of datasets that are used to perform analytics within the ProConnect Group. Each dataset contains a small description of what data in entails.
analytics_group_2.txt - contains second group of datasets that are used to perform analytics within the ProConnect Group. Each dataset contains a small description of what data in entails.