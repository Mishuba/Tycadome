You’ve successfully downloaded a copy of the Turbo data you requested. Please note that
it's possible your download may not include all the data described below.

If this file is blank, it may mean you haven’t shared enough data with Turbo for it to
be stored. If that doesn’t seem right, please double-check you have entered your info
correctly and resubmit your data request again.

Personal profile information can be found in turbo_user_profile.json and turbo_user_engagement.json.
The contents may include account status values used to determine the current state of your account
within the Turbo application and summary information about:
- Your identity (name, date of birth, address, phone, email, and occupation)
- Your income (both from your tax return and/or self-reported value)
- Your personal financial details (credit score, rent amount, homeownership status, alimony
and/or child support amount, tax filing status, and debt-to-income ratio)
- Your spouse's information, if applicable
- Campaigns you have received
- Purchases you have made

Turbo application use information can be found in turbo_user.json and turbo_user_experience.json.
The contents may include summary information about:
- Selections you've made within the Turbo application that allow us to provide a personalized
experience
- Use statistics to help identify the number of times you've used the Turbo application across
iOS, Android, and Web products, along with the time of the most recent visit in each application
- Account status values used to determine the current state of your account
- Preferences or settings used to provide a customized experience
- Your notification history